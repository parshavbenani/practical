﻿using System.ComponentModel.DataAnnotations;

namespace Exam2Web.Models
{
    public class Roles
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
