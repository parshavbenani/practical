﻿using Exam2Web.Models;
using Microsoft.EntityFrameworkCore;

namespace Exam2Web.Data
{
    public class ApplicationDbContext :DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        } 
        public DbSet<Roles> roles { get; set; }
        public DbSet<Employee> employees { get; set; }
    }
}
